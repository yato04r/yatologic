
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { 
  MessageCircle, 
  Zap, 
  Bot, 
  Users, 
  Clock, 
  TrendingUp, 
  CheckCircle, 
  ArrowRight,
  Smartphone,
  Settings,
  BarChart3
} from 'lucide-react';

function App() {
  const { toast } = useToast();

  const handleContactClick = () => {
    toast({
      title: "¡Contacto solicitado!",
      description: "🚧 Esta funcionalidad aún no está implementada, ¡pero no te preocupes! ¡Puedes solicitarla en tu próximo prompt! 🚀"
    });
  };

  const handleServiceClick = () => {
    toast({
      title: "¡Servicio solicitado!",
      description: "🚧 Esta funcionalidad aún no está implementada, ¡pero no te preocupes! ¡Puedes solicitarla en tu próximo prompt! 🚀"
    });
  };

  return (
    <>
      <Helmet>
        <title>Automatización WhatsApp con n8n - Bots Empresariales</title>
        <meta name="description" content="Automatiza tus procesos empresariales con WhatsApp y n8n. Creamos bots personalizados para mejorar la comunicación y eficiencia de tu negocio." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-teal-900 to-cyan-900">
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/20 to-cyan-600/20"></div>
          <div className="relative container mx-auto px-4 py-20">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center max-w-4xl mx-auto"
            >
              <div className="flex justify-center mb-8">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-full blur-xl opacity-30 animate-pulse"></div>
                  <div className="relative bg-gradient-to-r from-emerald-500 to-cyan-500 p-6 rounded-full">
                    <MessageCircle className="w-16 h-16 text-white" />
                  </div>
                </div>
              </div>
              
              <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-emerald-300 to-cyan-300 bg-clip-text text-transparent">
                Automatización WhatsApp
              </h1>
              
              <p className="text-xl md:text-2xl text-emerald-100 mb-8 leading-relaxed">
                Revoluciona tu negocio con <span className="font-semibold text-cyan-300">n8n</span> y 
                <span className="font-semibold text-emerald-300"> WhatsApp</span>. 
                Automatiza procesos, mejora la atención al cliente y aumenta tu productividad.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={handleServiceClick}
                  className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white px-8 py-6 text-lg rounded-xl shadow-2xl transform hover:scale-105 transition-all duration-300"
                >
                  <Bot className="w-5 h-5 mr-2" />
                  Crear Mi Bot
                </Button>
                <Button 
                  onClick={handleContactClick}
                  variant="outline" 
                  className="border-2 border-emerald-400 text-emerald-300 hover:bg-emerald-400 hover:text-emerald-900 px-8 py-6 text-lg rounded-xl backdrop-blur-sm"
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Contactar
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* What is n8n Section */}
        <section className="py-20 bg-gradient-to-r from-slate-900/50 to-emerald-900/30 backdrop-blur-sm">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                ¿Qué es <span className="text-emerald-400">n8n</span>?
              </h2>
              <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
                n8n es una plataforma de automatización de flujos de trabajo que te permite conectar 
                diferentes aplicaciones y servicios sin necesidad de programación compleja.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-6"
              >
                <div className="bg-gradient-to-r from-emerald-800/40 to-cyan-800/40 p-6 rounded-2xl backdrop-blur-sm border border-emerald-500/20">
                  <Zap className="w-8 h-8 text-emerald-400 mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">Automatización Visual</h3>
                  <p className="text-emerald-100">
                    Crea flujos de trabajo complejos con una interfaz visual intuitiva, 
                    conectando servicios mediante nodos arrastrables.
                  </p>
                </div>

                <div className="bg-gradient-to-r from-cyan-800/40 to-teal-800/40 p-6 rounded-2xl backdrop-blur-sm border border-cyan-500/20">
                  <Settings className="w-8 h-8 text-cyan-400 mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">Integración Flexible</h3>
                  <p className="text-emerald-100">
                    Conecta más de 400 aplicaciones diferentes, desde WhatsApp hasta 
                    sistemas CRM, bases de datos y herramientas de marketing.
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="relative"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-400/20 to-cyan-400/20 rounded-3xl blur-2xl"></div>
                <img  
                  className="relative w-full h-80 object-cover rounded-3xl shadow-2xl border border-emerald-500/30" 
                  alt="Interfaz de n8n mostrando flujos de trabajo"
                 src="https://images.unsplash.com/photo-1685586784800-42bac9c32db9" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* WhatsApp Business Benefits */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                WhatsApp para <span className="text-cyan-400">Empresas</span>
              </h2>
              <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
                Aprovecha el poder de WhatsApp Business API para automatizar 
                la comunicación con tus clientes de manera profesional.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="bg-gradient-to-br from-emerald-800/30 to-teal-800/30 p-8 rounded-2xl backdrop-blur-sm border border-emerald-500/20 hover:border-emerald-400/40 transition-all duration-300"
              >
                <Smartphone className="w-12 h-12 text-emerald-400 mb-6" />
                <h3 className="text-2xl font-semibold text-white mb-4">Comunicación Directa</h3>
                <p className="text-emerald-100">
                  Llega a tus clientes donde ya están. WhatsApp tiene más de 2 mil millones 
                  de usuarios activos mensualmente.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-gradient-to-br from-cyan-800/30 to-blue-800/30 p-8 rounded-2xl backdrop-blur-sm border border-cyan-500/20 hover:border-cyan-400/40 transition-all duration-300"
              >
                <Clock className="w-12 h-12 text-cyan-400 mb-6" />
                <h3 className="text-2xl font-semibold text-white mb-4">Respuesta 24/7</h3>
                <p className="text-emerald-100">
                  Los bots automatizados pueden responder consultas las 24 horas, 
                  mejorando la experiencia del cliente.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="bg-gradient-to-br from-teal-800/30 to-emerald-800/30 p-8 rounded-2xl backdrop-blur-sm border border-teal-500/20 hover:border-teal-400/40 transition-all duration-300"
              >
                <TrendingUp className="w-12 h-12 text-teal-400 mb-6" />
                <h3 className="text-2xl font-semibold text-white mb-4">Mayor Conversión</h3>
                <p className="text-emerald-100">
                  Las conversaciones por WhatsApp tienen tasas de apertura del 98% 
                  y respuesta del 45%.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Automation Processes */}
        <section className="py-20 bg-gradient-to-r from-slate-900/50 to-teal-900/30 backdrop-blur-sm">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                Procesos que <span className="text-emerald-400">Automatizamos</span>
              </h2>
              <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
                Transforma tu negocio automatizando estos procesos clave con WhatsApp y n8n.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: Users,
                  title: "Atención al Cliente",
                  description: "Respuestas automáticas, derivación de consultas y seguimiento de tickets.",
                  color: "emerald"
                },
                {
                  icon: BarChart3,
                  title: "Ventas y Marketing",
                  description: "Campañas automatizadas, seguimiento de leads y confirmación de pedidos.",
                  color: "cyan"
                },
                {
                  icon: CheckCircle,
                  title: "Confirmaciones",
                  description: "Citas médicas, reservas de restaurantes y confirmaciones de servicios.",
                  color: "teal"
                },
                {
                  icon: MessageCircle,
                  title: "Notificaciones",
                  description: "Alertas de stock, recordatorios de pagos y actualizaciones de estado.",
                  color: "emerald"
                },
                {
                  icon: Bot,
                  title: "Soporte Técnico",
                  description: "Diagnósticos automáticos, guías paso a paso y escalamiento de casos.",
                  color: "cyan"
                },
                {
                  icon: TrendingUp,
                  title: "Análisis y Reportes",
                  description: "Métricas de conversación, análisis de sentimientos y reportes automáticos.",
                  color: "teal"
                }
              ].map((process, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className={`bg-gradient-to-br from-${process.color}-800/30 to-${process.color}-900/30 p-6 rounded-2xl backdrop-blur-sm border border-${process.color}-500/20 hover:border-${process.color}-400/40 transition-all duration-300 hover:transform hover:scale-105`}
                >
                  <process.icon className={`w-10 h-10 text-${process.color}-400 mb-4`} />
                  <h3 className="text-xl font-semibold text-white mb-3">{process.title}</h3>
                  <p className="text-emerald-100 text-sm">{process.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Our Service */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                Nuestro <span className="text-cyan-400">Servicio</span>
              </h2>
              <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
                Creamos bots de WhatsApp personalizados para tu empresa, 
                adaptados a tus necesidades específicas y procesos de negocio.
              </p>
            </motion.div>

            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-8"
              >
                <div className="bg-gradient-to-r from-emerald-800/40 to-cyan-800/40 p-8 rounded-2xl backdrop-blur-sm border border-emerald-500/20">
                  <h3 className="text-2xl font-semibold text-white mb-6">¿Qué Incluye Nuestro Servicio?</h3>
                  
                  <div className="space-y-4">
                    {[
                      "Análisis completo de tus procesos empresariales",
                      "Diseño personalizado del flujo de conversación",
                      "Integración con tus sistemas existentes (CRM, ERP, etc.)",
                      "Configuración de WhatsApp Business API",
                      "Implementación completa en n8n",
                      "Pruebas exhaustivas y optimización",
                      "Capacitación para tu equipo",
                      "Soporte técnico continuo"
                    ].map((item, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <CheckCircle className="w-5 h-5 text-emerald-400 mt-1 flex-shrink-0" />
                        <span className="text-emerald-100">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-8"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 to-emerald-400/20 rounded-3xl blur-2xl"></div>
                  <img  
                    className="relative w-full h-80 object-cover rounded-3xl shadow-2xl border border-cyan-500/30" 
                    alt="Bot de WhatsApp en funcionamiento"
                   src="https://images.unsplash.com/photo-1685532431218-bb9296fa3b21" />
                </div>

                <div className="bg-gradient-to-r from-cyan-800/40 to-teal-800/40 p-6 rounded-2xl backdrop-blur-sm border border-cyan-500/20">
                  <h3 className="text-xl font-semibold text-white mb-4">Beneficios Inmediatos</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-cyan-400">90%</div>
                      <div className="text-emerald-100">Reducción en tiempo de respuesta</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-emerald-400">24/7</div>
                      <div className="text-emerald-100">Disponibilidad continua</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-teal-400">60%</div>
                      <div className="text-emerald-100">Aumento en satisfacción</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-cyan-400">40%</div>
                      <div className="text-emerald-100">Reducción en costos</div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-emerald-900/50 to-cyan-900/50 backdrop-blur-sm">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                ¿Listo para <span className="text-emerald-400">Automatizar</span> tu Negocio?
              </h2>
              
              <p className="text-xl text-emerald-100 mb-8">
                Únete a las empresas que ya están revolucionando su comunicación 
                con clientes mediante bots inteligentes de WhatsApp.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Button 
                  onClick={handleServiceClick}
                  className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-white px-10 py-6 text-xl rounded-xl shadow-2xl transform hover:scale-105 transition-all duration-300"
                >
                  <Bot className="w-6 h-6 mr-3" />
                  Crear Mi Bot Ahora
                  <ArrowRight className="w-6 h-6 ml-3" />
                </Button>
                
                <Button 
                  onClick={handleContactClick}
                  variant="outline" 
                  className="border-2 border-emerald-400 text-emerald-300 hover:bg-emerald-400 hover:text-emerald-900 px-10 py-6 text-xl rounded-xl backdrop-blur-sm"
                >
                  <MessageCircle className="w-6 h-6 mr-3" />
                  Consulta Gratuita
                </Button>
              </div>
              
              <p className="text-emerald-200 mt-6 text-sm">
                💡 Consulta inicial gratuita • ⚡ Implementación rápida • 🔒 Datos seguros
              </p>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-12 bg-slate-900/80 backdrop-blur-sm border-t border-emerald-500/20">
          <div className="container mx-auto px-4 text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-gradient-to-r from-emerald-500 to-cyan-500 p-3 rounded-full">
                <MessageCircle className="w-8 h-8 text-white" />
              </div>
            </div>
            
            <p className="text-emerald-100 mb-4">
              Automatización WhatsApp con n8n - Transformando la comunicación empresarial
            </p>
            
            <p className="text-emerald-300 text-sm">
              © 2024 - Servicios de Automatización WhatsApp. Potenciado por n8n.
            </p>
          </div>
        </footer>

        <Toaster />
      </div>
    </>
  );
}

export default App;
